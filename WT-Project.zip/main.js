

var termynal = new Termynal('#termynal');